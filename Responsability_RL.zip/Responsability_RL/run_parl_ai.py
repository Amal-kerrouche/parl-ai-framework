# run_parl_ai.py
"""
PARL-AI Simulation Runner

Runs simulations with correct RL sequencing:
- Single action selection per step
- Proper (s_t, a_t, r_t, s_t+1) transitions
- Three learner profiles and paper-inspired scenarios
- Mock mode for fast testing without API calls

Prints:
- Final responsibility per learner
- Final reliance state per learner
- Final scaffolding level per learner
- Transition path
- Selected actions
- Rewards
- Q-table summary
- Best learned action per state
- Example prompts and agent responses
- Scenario start-state verification
"""

import os
import sys
import random
import json
from typing import Dict, List, Any, Optional
from collections import defaultdict

from parl_ai_core import (
    Config, PARLAIEnvironment, LearnerProfile, RelianceState,
    RLAction, PedagogicalRole, InteractionTrace, BehaviorTrace,
    LearnerSimulator, create_profile, OPENAI_AVAILABLE, LLMResponse
)


# ============================================================================
# SIMULATION CONFIG
# ============================================================================

# MOCK MODE: Set to True to avoid GPT API calls during simulation
USE_MOCK_LLM = True

SCENARIOS = {
    'passive_dependency': {
        'start': RelianceState.PP,
        'target': RelianceState.PA,
        'desc': 'Passive Dependency: PP → PA',
        'profile': 'dependent'
    },
    'constructive_transition': {
        'start': RelianceState.AA,
        'target': RelianceState.CC,
        'desc': 'Constructive Transition: AA → CC',
        'profile': 'average'
    },
    'dependency_intervention': {
        'start': RelianceState.AP,
        'target': RelianceState.AA,
        'desc': 'Dependency Intervention: AP → AA',
        'profile': 'average'
    }
}


# ============================================================================
# MOCK LLM RESPONSE GENERATOR
# ============================================================================

def create_mock_llm_response(state: RelianceState, R: float, action: RLAction, role: PedagogicalRole) -> LLMResponse:
    """Create a realistic mock LLM response for testing."""
    
    # Generate appropriate feedback based on state and responsibility
    if R <= 0.30:
        feedback = "Let me provide step-by-step guidance to help you understand this concept."
        support_message = "I'll guide you through each step. First, let's identify what we know and what we need to find."
        verification_feedback = "You're building foundational understanding. Keep working through the steps."
        correct = False
        confidence = 0.6
    elif R < 0.70:
        feedback = "You're making good progress. Let me provide some structure while you fill in the details."
        support_message = "Here's a framework to work with. Can you complete the next part on your own?"
        verification_feedback = "Your reasoning is developing well. Consider how this connects to what you already know."
        correct = True
        confidence = 0.75
    else:
        feedback = "Excellent work! You're showing strong understanding. Reflect on your approach."
        support_message = "I'm impressed with your independent reasoning. What would be your next step?"
        verification_feedback = "Your reasoning is sound and well-structured. Keep up this autonomous work."
        correct = True
        confidence = 0.9
    
    # Adjust for state
    if state == RelianceState.PP:
        support_message = "Let's work through this together. What's your current understanding of the problem?"
    elif state == RelianceState.CC:
        support_message = "You're demonstrating excellent autonomy. How would you explain your solution strategy?"
    
    return LLMResponse(
        verifier_correct=correct,
        verifier_confidence=confidence,
        verifier_feedback=verification_feedback,
        assessment_grade=0.75,
        assessment_progress=0.7,
        assessment_struggle=0.3,
        instructor_feedback=feedback,
        support_role=role.value,
        support_action=action.value,
        support_message=support_message
    )


# ============================================================================
# BEHAVIOR GENERATOR FOR SPECIFIC STATES
# ============================================================================

def make_behavior_for_state(state: RelianceState) -> BehaviorTrace:
    """
    Create behavior traces that reliably infer to specific reliance states.
    
    Maps each state to appropriate behavior features.
    """
    # Base behavior for each state
    behaviors = {
        # PP: Passive help-seeking, Passive response-use
        RelianceState.PP: BehaviorTrace(
            direct_requests=0.8,
            clarification_requests=0.2,
            hint_usage=0.7,
            independent_retry=0.1,
            answer_acceptance=0.9,
            revision=0.1,
            verification=0.1,
            error_flagging=0.1,
            reflection=0.1,
            task_progress=0.3,
            struggle=0.7
        ),
        # PA: Passive help-seeking, Active response-use
        RelianceState.PA: BehaviorTrace(
            direct_requests=0.7,
            clarification_requests=0.3,
            hint_usage=0.6,
            independent_retry=0.2,
            answer_acceptance=0.4,
            revision=0.6,
            verification=0.4,
            error_flagging=0.3,
            reflection=0.3,
            task_progress=0.5,
            struggle=0.5
        ),
        # PC: Passive help-seeking, Constructive response-use
        RelianceState.PC: BehaviorTrace(
            direct_requests=0.6,
            clarification_requests=0.4,
            hint_usage=0.5,
            independent_retry=0.3,
            answer_acceptance=0.2,
            revision=0.7,
            verification=0.6,
            error_flagging=0.4,
            reflection=0.5,
            task_progress=0.6,
            struggle=0.4
        ),
        # AP: Active help-seeking, Passive response-use
        RelianceState.AP: BehaviorTrace(
            direct_requests=0.3,
            clarification_requests=0.6,
            hint_usage=0.4,
            independent_retry=0.3,
            answer_acceptance=0.7,
            revision=0.3,
            verification=0.3,
            error_flagging=0.3,
            reflection=0.3,
            task_progress=0.5,
            struggle=0.5
        ),
        # AA: Active help-seeking, Active response-use
        RelianceState.AA: BehaviorTrace(
            direct_requests=0.3,
            clarification_requests=0.5,
            hint_usage=0.4,
            independent_retry=0.4,
            answer_acceptance=0.4,
            revision=0.5,
            verification=0.5,
            error_flagging=0.4,
            reflection=0.4,
            task_progress=0.6,
            struggle=0.4
        ),
        # AC: Active help-seeking, Constructive response-use
        RelianceState.AC: BehaviorTrace(
            direct_requests=0.2,
            clarification_requests=0.5,
            hint_usage=0.3,
            independent_retry=0.5,
            answer_acceptance=0.2,
            revision=0.7,
            verification=0.6,
            error_flagging=0.5,
            reflection=0.6,
            task_progress=0.7,
            struggle=0.3
        ),
        # CP: Constructive help-seeking, Passive response-use
        RelianceState.CP: BehaviorTrace(
            direct_requests=0.2,
            clarification_requests=0.7,
            hint_usage=0.2,
            independent_retry=0.5,
            answer_acceptance=0.6,
            revision=0.3,
            verification=0.3,
            error_flagging=0.5,
            reflection=0.5,
            task_progress=0.6,
            struggle=0.4
        ),
        # CA: Constructive help-seeking, Active response-use
        RelianceState.CA: BehaviorTrace(
            direct_requests=0.1,
            clarification_requests=0.6,
            hint_usage=0.2,
            independent_retry=0.6,
            answer_acceptance=0.3,
            revision=0.6,
            verification=0.6,
            error_flagging=0.6,
            reflection=0.6,
            task_progress=0.7,
            struggle=0.3
        ),
        # CC: Constructive help-seeking, Constructive response-use
        RelianceState.CC: BehaviorTrace(
            direct_requests=0.1,
            clarification_requests=0.6,
            hint_usage=0.2,
            independent_retry=0.7,
            answer_acceptance=0.1,
            revision=0.8,
            verification=0.7,
            error_flagging=0.6,
            reflection=0.7,
            task_progress=0.8,
            struggle=0.2
        )
    }
    
    return behaviors.get(state, BehaviorTrace())


def verify_state_inference(env: PARLAIEnvironment, behavior: BehaviorTrace, expected_state: RelianceState) -> bool:
    """Verify that behavior infers to the expected state."""
    _, _, inferred_state = env.state_inference.infer_state(behavior)
    return inferred_state == expected_state


# ============================================================================
# OUTPUT PRINTER
# ============================================================================

class OutputPrinter:
    """Print simulation results."""
    
    @staticmethod
    def header(title: str):
        print("\n" + "=" * 80)
        print(f" {title}")
        print("=" * 80)
    
    @staticmethod
    def section(title: str):
        print("\n" + "-" * 80)
        print(f" {title}")
        print("-" * 80)
    
    @staticmethod
    def print_learner_summary(profile: LearnerProfile, traces: List[InteractionTrace]):
        """Print summary for a learner."""
        if not traces:
            print("  No traces.")
            return
        
        final_trace = traces[-1]
        final_R = final_trace.responsibility_after
        final_state = final_trace.state_t_plus_1
        final_scaffolding = final_trace.scaffolding_after
        
        print(f"  Final Responsibility: {final_R:.4f}")
        print(f"  Final Reliance State: {final_state.value}")
        print(f"  Final Scaffolding: {final_scaffolding:.4f}")
        
        # Transition path (states only)
        states = [t.state_t_plus_1.value for t in traces]
        unique = []
        for s in states:
            if not unique or unique[-1] != s:
                unique.append(s)
        path = " → ".join(unique[:10])
        if len(unique) > 10:
            path += f" → ... ({len(unique)} unique states)"
        print(f"  Transition Path: {path}")
        
        # Actions
        action_counts = defaultdict(int)
        for t in traces:
            action_counts[t.action_t.value] += 1
        actions = ", ".join([f"{a}: {c}" for a, c in action_counts.items()])
        print(f"  Actions: {actions}")
        
        # Rewards
        rewards = [t.reward_t for t in traces]
        print(f"  Avg Reward: {sum(rewards)/len(rewards):.4f}")
        print(f"  Min Reward: {min(rewards):.4f}")
        print(f"  Max Reward: {max(rewards):.4f}")
        
        # Example interaction (show full transition)
        example = traces[-3] if len(traces) >= 3 else traces[-1]
        print(f"\n  Example Transition (Step {example.step}):")
        print(f"    State_t: {example.state_t.value} → State_t+1: {example.state_t_plus_1.value}")
        print(f"    Action_t: {example.action_t.value}")
        print(f"    Reward_t: {example.reward_t:.3f}")
        print(f"    R: {example.responsibility_before:.3f} → {example.responsibility_after:.3f}")
        print(f"    Scaffolding: {example.scaffolding_before:.3f} → {example.scaffolding_after:.3f}")
        print(f"    Role: {example.role_t.value}")
        print(f"    Prompt: {example.prompt[:120]}...")
        print(f"    Response: {example.agent_response[:120]}...")
    
    @staticmethod
    def print_q_table(q_agent):
        """Print Q-table summary."""
        OutputPrinter.section("Q-TABLE SUMMARY")
        
        print("\n  Best Action per State:")
        for state in RelianceState:
            best = q_agent.best_action(state)
            q_val = q_agent.Q[state][best]
            print(f"    {state.value:4s} → {best.value:20s} (Q={q_val:.4f})")
        
        print("\n  Q-Table Values (Selected States):")
        selected = [RelianceState.PP, RelianceState.PA, RelianceState.AA,
                   RelianceState.AC, RelianceState.CC]
        for state in selected:
            print(f"    {state.value}:")
            for action in RLAction:
                q_val = q_agent.Q[state][action]
                print(f"      {action.value:20s}: {q_val:.4f}")
    
    @staticmethod
    def print_llm_response(llm_response, mock_mode: bool):
        """Print example LLM response."""
        mode = "MOCK" if mock_mode else "REAL GPT-4o-mini"
        OutputPrinter.section(f"EXAMPLE AGENT RESPONSE ({mode})")
        print(f"\n{json.dumps(llm_response.to_dict(), indent=2)}")
    
    @staticmethod
    def print_scenario(name: str, result: Dict[str, Any], verification_passed: bool):
        """Print scenario results."""
        OutputPrinter.section(f"SCENARIO: {name.upper()}")
        
        desc = SCENARIOS[name]['desc']
        start = result['start_state']
        target = result['target_state']
        reached = result['reached_target']
        
        print(f"  Description: {desc}")
        print(f"  Start State: {start.value}")
        print(f"  Target State: {target.value}")
        print(f"  Start-State Verification: {'✓ PASSED' if verification_passed else '✗ FAILED'}")
        print(f"  Target Reached: {'✓ YES' if reached else '✗ NO'}")
        
        traces = result['traces']
        if traces:
            final_trace = traces[-1]
            final_R = final_trace.responsibility_after
            final_state = final_trace.state_t_plus_1
            print(f"  Final R: {final_R:.4f}")
            print(f"  Final State: {final_state.value}")
            
            # Path
            states = [t.state_t_plus_1.value for t in traces]
            unique = []
            for s in states:
                if not unique or unique[-1] != s:
                    unique.append(s)
            print(f"  Path: {' → '.join(unique)}")
            
            # Show first transition
            first = traces[0]
            print(f"\n  First Transition:")
            print(f"    State_t: {first.state_t.value} → State_t+1: {first.state_t_plus_1.value}")
            print(f"    Action: {first.action_t.value}")
            print(f"    Reward: {first.reward_t:.3f}")


# ============================================================================
# MAIN
# ============================================================================

def main():
    """Main execution."""
    print("=" * 80)
    print(" PARL-AI: Pedagogically Adaptive Responsibility-Learning AI")
    print(" Research-Grade Implementation - Correct RL Sequencing")
    print(f" Mock Mode: {'ENABLED' if USE_MOCK_LLM else 'DISABLED'}")
    print("=" * 80)
    
    # Check OpenAI only if not in mock mode
    if not USE_MOCK_LLM:
        if not OPENAI_AVAILABLE:
            print("\n OpenAI library not installed.")
            print("   Install: pip install openai")
            sys.exit(1)
        
        if not os.getenv("OPENAI_API_KEY"):
            print("\n OPENAI_API_KEY environment variable not set.")
            print("   Set: export OPENAI_API_KEY='your-key-here'")
            sys.exit(1)
        
        print(f"\n✓ OpenAI key found")
        print(f"✓ Model: gpt-4o-mini (mandatory)")
    else:
        print("\n✓ Mock mode enabled - no API calls will be made")
    
    # Configuration
    config = Config()
    random.seed(config.random_seed)
    
    # Initialize environment with optional mock override
    env = PARLAIEnvironment(config)
    
    # Store original generate_response method for mock replacement
    original_generate = env.llm_agent.generate_response
    
    if USE_MOCK_LLM:
        def mock_generate_response(state, R, action, role, prompt, behavior):
            return create_mock_llm_response(state, R, action, role)
        
        # Replace with mock
        env.llm_agent.generate_response = mock_generate_response
    
    # ============================================================
    # 1. FULL SIMULATION - THREE LEARNER PROFILES
    # ============================================================
    
    OutputPrinter.header("FULL SIMULATION: THREE LEARNER PROFILES")
    
    profiles = ['autonomous', 'average', 'dependent']
    results = {}
    
    for profile_type in profiles:
        print(f"\nRunning {profile_type} learner...")
        
        # Reset environment
        env.reset()
        
        # Create profile and simulator
        profile = create_profile(profile_type)
        simulator = LearnerSimulator(profile, config)
        
        # Generate initial behavior (start from AA for full simulation)
        initial_behavior = make_behavior_for_state(RelianceState.AA)
        
        traces = []
        current_behavior = initial_behavior
        
        for step in range(50):
            # Full step with correct sequencing
            result, next_behavior = env.step_with_learner_simulator(
                current_behavior,
                simulator,
                {
                    'purpose': f'Step {step+1}: Solve the problem',
                    'task': 'mathematical reasoning problem',
                    'learner': profile.learner_id
                }
            )
            traces.append(result.trace)
            current_behavior = next_behavior
        
        results[profile_type] = {
            'profile': profile,
            'traces': traces,
            'simulator': simulator
        }
        
        OutputPrinter.section(f"{profile_type.upper()} LEARNER")
        OutputPrinter.print_learner_summary(profile, traces)
    
    # ============================================================
    # 2. Q-TABLE SUMMARY
    # ============================================================
    
    OutputPrinter.print_q_table(env.q_agent)
    
    # ============================================================
    # 3. SCENARIO TESTS WITH VERIFICATION
    # ============================================================
    
    OutputPrinter.header("PAPER-INSPIRED SCENARIOS")
    
    scenario_results = {}
    for scenario_name, scenario_config in SCENARIOS.items():
        print(f"\nRunning {scenario_name}...")
        
        # Reset environment
        env.reset()
        env.current_state = scenario_config['start']
        
        # Create profile
        profile = create_profile(scenario_config['profile'])
        simulator = LearnerSimulator(profile, config)
        
        # Generate behavior for the start state
        current_behavior = make_behavior_for_state(scenario_config['start'])
        
        # VERIFY the behavior infers to the correct state
        verification_passed = verify_state_inference(env, current_behavior, scenario_config['start'])
        
        if not verification_passed:
            print(f"  ⚠️ WARNING: Behavior did not infer to {scenario_config['start'].value}")
            print(f"  Inferred state: {env.state_inference.infer_state(current_behavior)[2].value}")
            print(f"  Adjusting behavior to ensure correct inference...")
            # Try a more extreme version
            extreme_behavior = make_behavior_for_state(scenario_config['start'])
            # Make it more extreme
            if scenario_config['start'] == RelianceState.PP:
                extreme_behavior.direct_requests = 0.95
                extreme_behavior.answer_acceptance = 0.95
            elif scenario_config['start'] == RelianceState.CC:
                extreme_behavior.revision = 0.9
                extreme_behavior.verification = 0.9
                extreme_behavior.reflection = 0.9
            current_behavior = extreme_behavior
            verification_passed = verify_state_inference(env, current_behavior, scenario_config['start'])
        
        if verification_passed:
            print(f"  ✓ Start-state verification PASSED: {scenario_config['start'].value}")
        else:
            print(f"  ✗ Start-state verification FAILED for {scenario_config['start'].value}")
        
        # Run the scenario
        traces = []
        
        for step in range(20):
            result, next_behavior = env.step_with_learner_simulator(
                current_behavior,
                simulator,
                {
                    'purpose': f'Scenario: {scenario_config["desc"]}',
                    'task': f'Step {step+1}',
                    'learner': profile.learner_id
                }
            )
            traces.append(result.trace)
            current_behavior = next_behavior
        
        reached = any(t.state_t_plus_1 == scenario_config['target'] for t in traces)
        scenario_results[scenario_name] = {
            'start_state': scenario_config['start'],
            'target_state': scenario_config['target'],
            'reached_target': reached,
            'traces': traces,
            'profile': profile,
            'verification_passed': verification_passed
        }
        
        OutputPrinter.print_scenario(scenario_name, scenario_results[scenario_name], verification_passed)
    
    # ============================================================
    # 4. EXAMPLE AGENT RESPONSE
    # ============================================================
    
    # Get an example response from the last scenario
    example_trace = traces[-1] if traces else None
    if example_trace:
        behavior_dict = example_trace.behavior_t.to_dict()
        
        # Use the current mode (mock or real)
        if USE_MOCK_LLM:
            llm_response = create_mock_llm_response(
                example_trace.state_t,
                example_trace.responsibility_before,
                example_trace.action_t,
                example_trace.role_t
            )
        else:
            # Restore original for this call if needed
            env.llm_agent.generate_response = original_generate
            llm_response = env.llm_agent.generate_response(
                example_trace.state_t,
                example_trace.responsibility_before,
                example_trace.action_t,
                example_trace.role_t,
                example_trace.prompt,
                behavior_dict
            )
        
        OutputPrinter.print_llm_response(llm_response, USE_MOCK_LLM)
    
    # ============================================================
    # 5. FINAL SUMMARY
    # ============================================================
    
    OutputPrinter.header("FINAL SUMMARY")
    
    print("\n  Learner Profiles Summary:")
    for profile_type, data in results.items():
        profile = data['profile']
        final_R = profile.final_responsibility or 0.0
        final_state = profile.final_state or RelianceState.AA
        final_scaffolding = profile.final_scaffolding or 0.0
        print(f"    {profile_type.upper():12s}: R={final_R:.4f}, "
              f"State={final_state.value}, Scaffolding={final_scaffolding:.4f}")
    
    print("\n  Scenario Start-State Verification:")
    for name, data in scenario_results.items():
        status = "✓ PASSED" if data['verification_passed'] else "✗ FAILED"
        print(f"    {name:25s}: {status}")
    
    print("\n  Model: gpt-4o-mini (✓)")
    print(f"  Mock Mode: {'ENABLED (no API calls)' if USE_MOCK_LLM else 'DISABLED (real API calls)'}")
    print(f"  Total Interactions: {sum(len(d['traces']) for d in results.values())}")
    print(f"  Q-Table Size: 9 states × 4 actions")
    print(f"  Correct RL Sequencing: ✓ (single action selection, true next state)")
    print(f"  Scenario Initialization: ✓ (behavior-based state inference)")
    
    print("\n" + "=" * 80)
    print(" SIMULATION COMPLETE")
    print("=" * 80)


if __name__ == "__main__":
    main()