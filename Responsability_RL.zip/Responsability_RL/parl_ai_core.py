# parl_ai_core.py
"""
PARL-AI (Personalized Adaptive Reinforcement Learning for AI-Augmented Learning)
A responsibility-aware reinforcement learning framework for regulating learner-GenAI interaction as described in the paper.

Implements:
- 9 reliance states (PP to CC) from help-seeking and response-use
- Responsibility update: R(t+1) = R(t) + α·Success - β·Struggle
- Reward function: r(t) = α·P(t) + β·A(t) - γ·L(t)
- Scaffolding fade: s(t+1) = s(t) - λ·P(t)·R(t)·(1-s(t))
- Q-learning with 4 actions: hint, reflection, partial_guidance, withholding
- 3 pedagogical roles: Coach, Partner, Mentor
- Single GPT-4o-mini call per interaction with structured JSON output
- Correct RL sequencing: single action selection, proper next state inference
"""

import os
import json
import random
import math
from dataclasses import dataclass, field
from enum import Enum
from typing import Dict, List, Optional, Tuple, Any
from collections import defaultdict

# Import OpenAI SDK
try:
    from openai import OpenAI
    OPENAI_AVAILABLE = True
except ImportError:
    OPENAI_AVAILABLE = False


# ============================================================================
# CONFIGURATION
# ============================================================================

@dataclass
class Config:
    """Central configuration for PARL-AI."""
    
    # OpenAI - MANDATORY
    openai_model: str = "gpt-4o-mini"
    openai_temperature: float = 0.3
    openai_max_tokens: int = 500
    
    # RL parameters
    learning_rate: float = 0.1
    discount_factor: float = 0.95
    exploration_rate: float = 0.3
    exploration_decay: float = 0.995
    min_exploration: float = 0.05
    
    # Responsibility parameters
    alpha_success: float = 0.15
    beta_struggle: float = 0.15
    
    # Reward parameters
    alpha_progress: float = 0.35
    beta_engagement: float = 0.35
    gamma_reliance: float = 0.30
    
    # Scaffolding parameters
    lambda_fade: float = 0.08
    initial_scaffolding: float = 0.80
    min_scaffolding: float = 0.10
    max_scaffolding: float = 1.00
    
    # Role thresholds
    low_responsibility_threshold: float = 0.30
    high_responsibility_threshold: float = 0.70
    
    # State thresholds
    passive_threshold: float = 0.33
    active_threshold: float = 0.66
    
    # Simulation
    random_seed: int = 42
    
    # API key from environment
    @property
    def openai_api_key(self) -> str:
        key = os.getenv("OPENAI_API_KEY")
        if not key:
            raise RuntimeError(
                "OPENAI_API_KEY environment variable not set.\n"
                "Set it with: export OPENAI_API_KEY='your-key-here'"
            )
        return key


# ============================================================================
# ENUMS - PAPER-SPECIFIC DEFINITIONS
# ============================================================================

class EngagementLevel(Enum):
    """Three levels of learner engagement."""
    PASSIVE = "passive"
    ACTIVE = "active"
    CONSTRUCTIVE = "constructive"


class RelianceState(Enum):
    """
    Nine reliance states from the paper.
    Format: (Help-Seeking, Response-Use)
    P = Passive, A = Active, C = Constructive
    """
    PP = "PP"
    PA = "PA"
    PC = "PC"
    AP = "AP"
    AA = "AA"
    AC = "AC"
    CP = "CP"
    CA = "CA"
    CC = "CC"
    
    @classmethod
    def from_help_response(cls, help_level: str, response_level: str) -> 'RelianceState':
        return cls[f"{help_level}{response_level}"]
    
    def help_level(self) -> str:
        return self.value[0]
    
    def response_level(self) -> str:
        return self.value[1]
    
    def to_engagement(self) -> EngagementLevel:
        if self in [RelianceState.PP, RelianceState.PA, RelianceState.AP]:
            return EngagementLevel.PASSIVE
        elif self in [RelianceState.PC, RelianceState.AC, RelianceState.CA]:
            return EngagementLevel.ACTIVE
        else:
            return EngagementLevel.CONSTRUCTIVE


class RLAction(Enum):
    """Four RL actions from the paper."""
    HINT = "hint"
    REFLECTION = "reflection"
    PARTIAL_GUIDANCE = "partial_guidance"
    WITHHOLDING = "withholding"


class PedagogicalRole(Enum):
    """
    Three pedagogical roles from the paper.
    Low R (≤ 0.30) → Coach
    Medium R (0.30 < R < 0.70) → Partner
    High R (≥ 0.70) → Mentor
    """
    COACH = "coach"
    PARTNER = "partner"
    MENTOR = "mentor"
    
    @classmethod
    def from_responsibility(cls, R: float, config: Config) -> 'PedagogicalRole':
        if R <= config.low_responsibility_threshold:
            return cls.COACH
        elif R < config.high_responsibility_threshold:
            return cls.PARTNER
        else:
            return cls.MENTOR


# ============================================================================
# DATACLASSES
# ============================================================================

@dataclass
class BehaviorTrace:
    """Observable behavior trace from the paper."""
    direct_requests: float = 0.0
    clarification_requests: float = 0.0
    hint_usage: float = 0.0
    independent_retry: float = 0.0
    answer_acceptance: float = 0.0
    revision: float = 0.0
    verification: float = 0.0
    error_flagging: float = 0.0
    reflection: float = 0.0
    task_progress: float = 0.0
    struggle: float = 0.0
    
    def to_dict(self) -> Dict[str, float]:
        return {
            'direct_requests': self.direct_requests,
            'clarification_requests': self.clarification_requests,
            'hint_usage': self.hint_usage,
            'independent_retry': self.independent_retry,
            'answer_acceptance': self.answer_acceptance,
            'revision': self.revision,
            'verification': self.verification,
            'error_flagging': self.error_flagging,
            'reflection': self.reflection,
            'task_progress': self.task_progress,
            'struggle': self.struggle
        }


@dataclass
class InteractionTrace:
    """Complete interaction trace with both states."""
    step: int
    behavior_t: BehaviorTrace
    behavior_t_plus_1: BehaviorTrace
    state_t: RelianceState
    state_t_plus_1: RelianceState
    action_t: RLAction
    role_t: PedagogicalRole
    reward_t: float
    responsibility_before: float
    responsibility_after: float
    scaffolding_before: float
    scaffolding_after: float
    prompt: str
    agent_response: str
    engagement: EngagementLevel


@dataclass
class PendingTransition:
    """
    Pending transition between begin_step and complete_step.
    Captures all state before learner responds.
    """
    step: int
    behavior_t: BehaviorTrace
    state_t: RelianceState
    action_t: RLAction
    role_t: PedagogicalRole
    R_before: float
    scaffolding_before: float
    prompt: str
    llm_response: Any  # LLMResponse
    context: Dict[str, Any]


@dataclass
class StepResult:
    """Complete step result with explicit (s_t, a_t, r_t, s_t+1)."""
    step: int
    state_t: RelianceState
    state_t_plus_1: RelianceState
    action_t: RLAction
    role_t: PedagogicalRole
    reward_t: float
    R_before: float
    R_after: float
    scaffolding_before: float
    scaffolding_after: float
    prompt: str
    agent_response: str
    behavior_t: BehaviorTrace
    behavior_t_plus_1: BehaviorTrace
    engagement: EngagementLevel
    trace: InteractionTrace


@dataclass
class LLMResponse:
    """Structured response from single GPT-4o-mini call."""
    verifier_correct: bool = False
    verifier_confidence: float = 0.0
    verifier_feedback: str = ""
    assessment_grade: float = 0.0
    assessment_progress: float = 0.0
    assessment_struggle: float = 0.0
    instructor_feedback: str = ""
    support_role: str = ""
    support_action: str = ""
    support_message: str = ""
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'verifier_agent': {
                'correct': self.verifier_correct,
                'confidence': self.verifier_confidence,
                'verification_feedback': self.verifier_feedback
            },
            'assessment_agent': {
                'grade': self.assessment_grade,
                'task_progress': self.assessment_progress,
                'struggle': self.assessment_struggle
            },
            'instructor_agent': {
                'feedback': self.instructor_feedback
            },
            'support_agent': {
                'role': self.support_role,
                'action': self.support_action,
                'message': self.support_message
            }
        }


@dataclass
class LearnerProfile:
    """Learner profile from paper."""
    learner_id: str
    initial_autonomy: float = 0.5
    current_autonomy: float = 0.5
    competence: float = 0.5
    help_tendency: float = 0.5
    response_skill: float = 0.5
    
    # History
    states: List[RelianceState] = field(default_factory=list)
    responsibilities: List[float] = field(default_factory=list)
    actions: List[RLAction] = field(default_factory=list)
    scaffoldings: List[float] = field(default_factory=list)
    rewards: List[float] = field(default_factory=list)
    behaviors: List[BehaviorTrace] = field(default_factory=list)
    
    # Metrics
    success_count: int = 0
    constructive_count: int = 0
    passive_count: int = 0
    total_steps: int = 0
    
    @property
    def final_responsibility(self) -> Optional[float]:
        return self.responsibilities[-1] if self.responsibilities else None
    
    @property
    def final_state(self) -> Optional[RelianceState]:
        return self.states[-1] if self.states else None
    
    @property
    def final_scaffolding(self) -> Optional[float]:
        return self.scaffoldings[-1] if self.scaffoldings else None


# ============================================================================
# STATE INFERENCE ENGINE
# ============================================================================

class StateInferenceEngine:
    """Infers reliance state from behavior per paper."""
    
    def __init__(self, config: Config):
        self.config = config
        
    def infer_help_seeking(self, behavior: BehaviorTrace) -> float:
        constructive = (
            behavior.clarification_requests * 0.30 +
            behavior.independent_retry * 0.25 +
            behavior.reflection * 0.20 +
            behavior.verification * 0.15 +
            behavior.error_flagging * 0.10
        )
        passive = (
            behavior.direct_requests * 0.40 +
            behavior.hint_usage * 0.30 +
            behavior.answer_acceptance * 0.30
        )
        total = constructive + passive
        return 0.5 if total == 0 else max(0.0, min(1.0, constructive / total))
    
    def infer_response_use(self, behavior: BehaviorTrace) -> float:
        constructive = (
            behavior.revision * 0.30 +
            behavior.verification * 0.25 +
            behavior.reflection * 0.20 +
            behavior.independent_retry * 0.15 +
            behavior.error_flagging * 0.10
        )
        passive = (
            behavior.answer_acceptance * 0.40 +
            behavior.direct_requests * 0.30 +
            behavior.hint_usage * 0.30
        )
        total = constructive + passive
        return 0.5 if total == 0 else max(0.0, min(1.0, constructive / total))
    
    def map_to_level(self, value: float) -> str:
        if value <= self.config.passive_threshold:
            return 'P'
        elif value <= self.config.active_threshold:
            return 'A'
        else:
            return 'C'
    
    def infer_state(self, behavior: BehaviorTrace) -> Tuple[float, float, RelianceState]:
        help_seeking = self.infer_help_seeking(behavior)
        response_use = self.infer_response_use(behavior)
        h_level = self.map_to_level(help_seeking)
        r_level = self.map_to_level(response_use)
        state = RelianceState.from_help_response(h_level, r_level)
        return help_seeking, response_use, state


# ============================================================================
# RESPONSIBILITY ESTIMATOR
# ============================================================================

class ResponsibilityEstimator:
    """
    Per paper: R(t+1) = R(t) + α·Success - β·Struggle
    """
    
    def __init__(self, config: Config):
        self.config = config
        
    def estimate(self, behavior: BehaviorTrace, current_R: float) -> float:
        success = (
            behavior.task_progress * 0.5 +
            (1.0 - behavior.answer_acceptance) * 0.2 +
            behavior.revision * 0.15 +
            behavior.verification * 0.15
        )
        success = max(0.0, min(1.0, success))
        
        struggle = (
            behavior.struggle * 0.5 +
            behavior.answer_acceptance * 0.2 +
            behavior.direct_requests * 0.15 +
            behavior.hint_usage * 0.15
        )
        struggle = max(0.0, min(1.0, struggle))
        
        new_R = current_R + self.config.alpha_success * success - self.config.beta_struggle * struggle
        return max(0.0, min(1.0, new_R))


# ============================================================================
# REWARD FUNCTION
# ============================================================================

class RewardFunction:
    """
    Per paper: r(t) = α·P(t) + β·A(t) - γ·L(t)
    """
    
    def __init__(self, config: Config):
        self.config = config
        
    def compute(self, behavior: BehaviorTrace, state: RelianceState) -> float:
        P = behavior.task_progress
        
        engagement_score = 0.0
        if state in [RelianceState.CC, RelianceState.CA, RelianceState.AC]:
            engagement_score += 0.5
        elif state in [RelianceState.PC, RelianceState.CP]:
            engagement_score += 0.3
        elif state in [RelianceState.AA, RelianceState.AP, RelianceState.PA]:
            engagement_score += 0.2
        engagement_score += (
            behavior.revision * 0.15 +
            behavior.verification * 0.15 +
            behavior.reflection * 0.10 +
            behavior.independent_retry * 0.10
        )
        A = max(0.0, min(1.0, engagement_score))
        
        reliance_score = 0.0
        if state in [RelianceState.PP, RelianceState.PA, RelianceState.AP]:
            reliance_score += 0.5
        elif state in [RelianceState.PC, RelianceState.CP]:
            reliance_score += 0.3
        reliance_score += (
            behavior.answer_acceptance * 0.25 +
            behavior.direct_requests * 0.15 +
            behavior.hint_usage * 0.10
        )
        L = max(0.0, min(1.0, reliance_score))
        
        reward = (
            self.config.alpha_progress * P +
            self.config.beta_engagement * A -
            self.config.gamma_reliance * L
        )
        return reward


# ============================================================================
# SCAFFOLDING CONTROLLER
# ============================================================================

class ScaffoldingController:
    """
    Per paper: s(t+1) = s(t) - λ·P(t)·R(t)·(1-s(t))
    """
    
    def __init__(self, config: Config):
        self.config = config
        self.current = config.initial_scaffolding
        
    def update(self, task_progress: float, responsibility: float, action: RLAction) -> float:
        lam = self.config.lambda_fade
        P = task_progress
        R = responsibility
        s = self.current
        
        fade = lam * P * R * (1 - s)
        
        if action == RLAction.WITHHOLDING:
            fade *= 1.5
        elif action == RLAction.PARTIAL_GUIDANCE:
            fade *= 1.0
        else:
            fade *= 0.7
        
        new_s = s - fade
        new_s = max(self.config.min_scaffolding, min(self.config.max_scaffolding, new_s))
        self.current = new_s
        return new_s


# ============================================================================
# PROMPT CONSTRUCTOR
# ============================================================================

class PromptConstructor:
    """
    Constructs prompts per paper contract.
    [Resp: {R} — State: {state} — Action: {action} — Role: {role}]
    """
    
    @staticmethod
    def construct(state: RelianceState, R: float, action: RLAction,
                  role: PedagogicalRole, purpose: str,
                  scaffolding: float, context: Dict[str, Any]) -> str:
        if R <= 0.30:
            allowed = "Provide clear, step-by-step guidance"
            forbidden = "Do not withhold support"
        elif R < 0.70:
            allowed = "Provide partial structure and guidance"
            forbidden = "Do not give complete solutions"
        else:
            allowed = "Use reflective questions only"
            forbidden = "Do not provide direct answers"
        
        header = f"[Resp: {R:.2f} — State: {state.value} — Action: {action.value} — Role: {role.value}]"
        
        learner_instruction = {
            RLAction.HINT: "Consider this hint to guide your thinking.",
            RLAction.REFLECTION: "Reflect on your current understanding.",
            RLAction.PARTIAL_GUIDANCE: "Use this partial guidance to structure your work.",
            RLAction.WITHHOLDING: "Try to solve this independently first."
        }.get(action, "Continue working on this.")
        
        prompt = f"""{header}

Purpose: {purpose}
Task Context: {context.get('task', 'problem solving')}
Learner: {context.get('learner', 'learner')}

Allowed Support: {allowed}
Forbidden Behavior: {forbidden}
Scaffolding Level: {scaffolding:.2f}

{learner_instruction}

Please explain your reasoning and approach to this task."""
        
        return prompt


# ============================================================================
# Q-LEARNING AGENT
# ============================================================================

class QLearningAgent:
    """
    Q-learning with 4 actions per paper.
    Update: Q(s,a) ← Q(s,a) + η[r + γ max Q(s',a') - Q(s,a)]
    """
    
    def __init__(self, config: Config):
        self.config = config
        self.lr = config.learning_rate
        self.gamma = config.discount_factor
        self.epsilon = config.exploration_rate
        self.epsilon_min = config.min_exploration
        self.epsilon_decay = config.exploration_decay
        
        self.Q: Dict[RelianceState, Dict[RLAction, float]] = {}
        self.visits: Dict[Tuple[RelianceState, RLAction], int] = defaultdict(int)
        self._init_Q()
    
    def _init_Q(self):
        for state in RelianceState:
            self.Q[state] = {}
            for action in RLAction:
                self.Q[state][action] = random.uniform(0, 0.1)
    
    def select_action(self, state: RelianceState, deterministic: bool = False) -> RLAction:
        if deterministic or random.random() > self.epsilon:
            return self.best_action(state)
        else:
            return random.choice(list(RLAction))
    
    def best_action(self, state: RelianceState) -> RLAction:
        return max(self.Q[state], key=self.Q[state].get)
    
    def update(self, state: RelianceState, action: RLAction,
               reward: float, next_state: RelianceState) -> float:
        current_q = self.Q[state][action]
        max_next_q = max(self.Q[next_state].values())
        td_target = reward + self.gamma * max_next_q
        td_error = td_target - current_q
        new_q = current_q + self.lr * td_error
        self.Q[state][action] = new_q
        self.visits[(state, action)] += 1
        self.epsilon = max(self.epsilon_min, self.epsilon * self.epsilon_decay)
        return td_error
    
    def get_policy(self) -> Dict[str, Dict[str, float]]:
        return {
            state.value: {action.value: q for action, q in actions.items()}
            for state, actions in self.Q.items()
        }


# ============================================================================
# LLM AGENTS - SINGLE GPT-4O-MINI CALL
# ============================================================================

class PARLAIAgent:
    """Unified LLM agent with single GPT-4o-mini call."""
    
    def __init__(self, config: Config):
        self.config = config
        if not OPENAI_AVAILABLE:
            raise ImportError("OpenAI library required: pip install openai")
        self.client = OpenAI(api_key=config.openai_api_key)
        self.model = config.openai_model  # MANDATORY: gpt-4o-mini
    
    def generate_response(self, state: RelianceState, R: float,
                         action: RLAction, role: PedagogicalRole,
                         prompt: str, behavior: Dict[str, float]) -> LLMResponse:
        system_prompt = f"""You are PARL-AI, a responsibility-aware tutoring system.

Current context:
- State: {state.value}
- Responsibility: {R:.2f}
- Action: {action.value}
- Role: {role.value}

Respond with JSON only:
{{
  "verifier_agent": {{
    "correct": true/false,
    "confidence": 0.0-1.0,
    "verification_feedback": "string"
  }},
  "assessment_agent": {{
    "grade": 0.0-1.0,
    "task_progress": 0.0-1.0,
    "struggle": 0.0-1.0
  }},
  "instructor_agent": {{
    "feedback": "string"
  }},
  "support_agent": {{
    "role": "{role.value}",
    "action": "{action.value}",
    "message": "string"
  }}
}}

Rules:
- R ≤ 0.30: provide direct guidance
- 0.30 < R < 0.70: provide partial scaffolding
- R ≥ 0.70: use reflective prompting only, no direct answers"""
        
        user_prompt = f"""Learner behavior: {json.dumps(behavior, indent=2)}

Prompt: {prompt}

Respond with JSON only."""
        
        try:
            response = self.client.chat.completions.create(
                model=self.model,
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": user_prompt}
                ],
                temperature=self.config.openai_temperature,
                max_tokens=self.config.openai_max_tokens,
                response_format={"type": "json_object"}
            )
            
            data = json.loads(response.choices[0].message.content)
            verifier = data.get('verifier_agent', {})
            assessment = data.get('assessment_agent', {})
            instructor = data.get('instructor_agent', {})
            support = data.get('support_agent', {})
            
            return LLMResponse(
                verifier_correct=verifier.get('correct', False),
                verifier_confidence=verifier.get('confidence', 0.0),
                verifier_feedback=verifier.get('verification_feedback', ''),
                assessment_grade=assessment.get('grade', 0.0),
                assessment_progress=assessment.get('task_progress', 0.0),
                assessment_struggle=assessment.get('struggle', 0.0),
                instructor_feedback=instructor.get('feedback', ''),
                support_role=support.get('role', role.value),
                support_action=support.get('action', action.value),
                support_message=support.get('message', '')
            )
        except Exception as e:
            return LLMResponse(
                verifier_correct=False,
                verifier_confidence=0.5,
                verifier_feedback=f"Error: {str(e)}",
                assessment_grade=0.5,
                assessment_progress=0.5,
                assessment_struggle=0.5,
                instructor_feedback="Please continue working.",
                support_role=role.value,
                support_action=action.value,
                support_message="Let me know if you need help."
            )


# ============================================================================
# LEARNER SIMULATOR
# ============================================================================

class LearnerSimulator:
    """Stochastic learner simulator for testing."""
    
    def __init__(self, profile: LearnerProfile, config: Config):
        self.profile = profile
        self.config = config
        self.step_count = 0
        self.history: List[BehaviorTrace] = []
    
    def generate_behavior(self, state: RelianceState, action: RLAction,
                         scaffolding: float) -> BehaviorTrace:
        self.step_count += 1
        
        help_tendency = self.profile.help_tendency
        response_skill = self.profile.response_skill
        competence = self.profile.competence
        autonomy = self.profile.current_autonomy
        
        action_effects = {
            RLAction.HINT: (0.10, 0.10),
            RLAction.REFLECTION: (0.20, 0.15),
            RLAction.PARTIAL_GUIDANCE: (0.05, 0.25),
            RLAction.WITHHOLDING: (0.25, 0.20)
        }
        h_effect, r_effect = action_effects.get(action, (0.0, 0.0))
        s_effect = 1.0 - scaffolding
        
        state_mods = {
            RelianceState.PP: (-0.20, -0.20),
            RelianceState.PA: (-0.15, 0.00),
            RelianceState.PC: (-0.15, 0.20),
            RelianceState.AP: (0.00, -0.20),
            RelianceState.AA: (0.00, 0.00),
            RelianceState.AC: (0.00, 0.20),
            RelianceState.CP: (0.20, -0.20),
            RelianceState.CA: (0.20, 0.00),
            RelianceState.CC: (0.20, 0.20)
        }
        h_mod, r_mod = state_mods.get(state, (0.0, 0.0))
        
        h_noise = random.uniform(-0.10, 0.10)
        r_noise = random.uniform(-0.10, 0.10)
        
        help_seeking = max(0.0, min(1.0,
            help_tendency + h_effect + h_mod + s_effect * 0.1 + h_noise
        ))
        response_use = max(0.0, min(1.0,
            response_skill + r_effect + r_mod + s_effect * 0.1 + r_noise
        ))
        
        progress = max(0.0, min(1.0,
            competence * 0.4 + response_use * 0.3 + help_seeking * 0.3 + random.uniform(-0.1, 0.1)
        ))
        struggle = max(0.0, min(1.0,
            1.0 - competence * 0.5 + random.uniform(-0.1, 0.1)
        ))
        
        behavior = BehaviorTrace(
            direct_requests=max(0.0, min(1.0, 1.0 - help_seeking * 0.7)),
            clarification_requests=max(0.0, min(1.0, help_seeking * 0.5 + random.uniform(-0.05, 0.05))),
            hint_usage=max(0.0, min(1.0, 1.0 - scaffolding + random.uniform(-0.05, 0.05))),
            independent_retry=max(0.0, min(1.0, autonomy * 0.5 + response_use * 0.3 + random.uniform(-0.05, 0.05))),
            answer_acceptance=max(0.0, min(1.0, 1.0 - response_use * 0.5 + random.uniform(-0.05, 0.05))),
            revision=max(0.0, min(1.0, response_use * 0.5 + random.uniform(-0.05, 0.05))),
            verification=max(0.0, min(1.0, response_use * 0.4 + random.uniform(-0.05, 0.05))),
            error_flagging=max(0.0, min(1.0, competence * 0.3 + random.uniform(-0.05, 0.05))),
            reflection=max(0.0, min(1.0, help_seeking * 0.3 + response_use * 0.3 + random.uniform(-0.05, 0.05))),
            task_progress=progress,
            struggle=struggle
        )
        
        self._update_profile(behavior, progress)
        self.history.append(behavior)
        return behavior
    
    def _update_profile(self, behavior: BehaviorTrace, progress: float):
        autonomy_delta = (
            0.03 if behavior.verification > 0.5 and behavior.reflection > 0.5 else
            0.01 if behavior.revision > 0.5 else
            -0.02 if behavior.answer_acceptance > 0.7 else
            -0.01
        )
        self.profile.current_autonomy = max(0.0, min(1.0,
            self.profile.current_autonomy + autonomy_delta * random.uniform(0.8, 1.2)
        ))
        
        comp_delta = 0.03 * progress - 0.01 * (1.0 - progress)
        self.profile.competence = max(0.0, min(1.0,
            self.profile.competence + comp_delta * random.uniform(0.8, 1.2)
        ))
        
        self.profile.help_tendency = max(0.0, min(1.0,
            self.profile.help_tendency + 0.005 * (behavior.clarification_requests - 0.5)
        ))
        self.profile.response_skill = max(0.0, min(1.0,
            self.profile.response_skill + 0.005 * (behavior.revision - 0.5)
        ))
        
        self.profile.total_steps += 1
        if progress > 0.7:
            self.profile.success_count += 1


# ============================================================================
# PARL-AI ENVIRONMENT - CORRECT RL SEQUENCING
# ============================================================================

class PARLAIEnvironment:
    """
    PARL-AI environment with correct RL sequencing.
    
    Correct sequence:
    1. begin_step: infer state_t, select action_t once, generate prompt
    2. Learner responds to action_t → behavior_t+1
    3. complete_step: infer state_t+1, compute reward, update Q(s_t, a_t, r_t, s_t+1)
    
    Single action selection. No hardcoded transitions.
    """
    
    def __init__(self, config: Config):
        self.config = config
        self.state_inference = StateInferenceEngine(config)
        self.responsibility_estimator = ResponsibilityEstimator(config)
        self.reward_function = RewardFunction(config)
        self.scaffolding_controller = ScaffoldingController(config)
        self.prompt_constructor = PromptConstructor()
        self.q_agent = QLearningAgent(config)
        self.llm_agent = PARLAIAgent(config)
        
        self.current_state = RelianceState.AA
        self.current_R = 0.5
        self.current_scaffolding = config.initial_scaffolding
        self.history: List[InteractionTrace] = []
        self.step_count = 0
    
    def reset(self):
        self.current_state = RelianceState.AA
        self.current_R = 0.5
        self.current_scaffolding = self.config.initial_scaffolding
        self.history = []
        self.step_count = 0
    
    def begin_step(self, behavior_t: BehaviorTrace, context: Dict[str, Any] = None) -> PendingTransition:
        """
        Phase 1: Observe behavior_t, select action_t, generate support.
        
        Returns PendingTransition with all state needed for completion.
        """
        self.step_count += 1
        context = context or {}
        
        # 1. Infer state_t from behavior_t
        _, _, state_t = self.state_inference.infer_state(behavior_t)
        self.current_state = state_t
        
        # 2. Select action_t ONCE
        action_t = self.q_agent.select_action(state_t)
        
        # 3. Map to role
        role_t = PedagogicalRole.from_responsibility(self.current_R, self.config)
        
        # 4. Construct prompt
        purpose = context.get('purpose', 'Solve the problem step by step')
        prompt = self.prompt_constructor.construct(
            state_t, self.current_R, action_t, role_t,
            purpose, self.current_scaffolding, context
        )
        
        # 5. Generate LLM response
        behavior_dict = behavior_t.to_dict()
        llm_response = self.llm_agent.generate_response(
            state_t, self.current_R, action_t, role_t,
            prompt, behavior_dict
        )
        
        # 6. Create pending transition
        return PendingTransition(
            step=self.step_count,
            behavior_t=behavior_t,
            state_t=state_t,
            action_t=action_t,
            role_t=role_t,
            R_before=self.current_R,
            scaffolding_before=self.current_scaffolding,
            prompt=prompt,
            llm_response=llm_response,
            context=context
        )
    
    def complete_step(self, pending: PendingTransition, behavior_t_plus_1: BehaviorTrace) -> StepResult:
        """
        Phase 2: Observe behavior_t+1, infer state_t+1, update Q-learning.
        
        Uses the same action_t from pending for Q-learning update.
        """
        # 1. Infer state_t+1 from behavior_t+1
        _, _, state_t_plus_1 = self.state_inference.infer_state(behavior_t_plus_1)
        
        # 2. Compute reward using state_t+1 (per paper formula)
        reward_t = self.reward_function.compute(behavior_t_plus_1, state_t_plus_1)
        
        # 3. Update responsibility using behavior_t+1 (per paper formula)
        R_before = pending.R_before
        R_after = self.responsibility_estimator.estimate(behavior_t_plus_1, R_before)
        self.current_R = R_after
        
        # 4. Update scaffolding using behavior_t+1 and R_after (per paper formula)
        scaffolding_before = pending.scaffolding_before
        scaffolding_after = self.scaffolding_controller.update(
            behavior_t_plus_1.task_progress, R_after, pending.action_t
        )
        self.current_scaffolding = scaffolding_after
        
        # 5. Update Q-learning with (s_t, a_t, r_t, s_t+1)
        # Uses the SAME action_t from pending, not a new selection
        self.q_agent.update(
            pending.state_t,
            pending.action_t,
            reward_t,
            state_t_plus_1
        )
        
        # 6. Create trace
        engagement = state_t_plus_1.to_engagement()
        trace = InteractionTrace(
            step=pending.step,
            behavior_t=pending.behavior_t,
            behavior_t_plus_1=behavior_t_plus_1,
            state_t=pending.state_t,
            state_t_plus_1=state_t_plus_1,
            action_t=pending.action_t,
            role_t=pending.role_t,
            reward_t=reward_t,
            responsibility_before=R_before,
            responsibility_after=R_after,
            scaffolding_before=scaffolding_before,
            scaffolding_after=scaffolding_after,
            prompt=pending.prompt,
            agent_response=pending.llm_response.support_message,
            engagement=engagement
        )
        self.history.append(trace)
        
        # 7. Return complete result
        return StepResult(
            step=pending.step,
            state_t=pending.state_t,
            state_t_plus_1=state_t_plus_1,
            action_t=pending.action_t,
            role_t=pending.role_t,
            reward_t=reward_t,
            R_before=R_before,
            R_after=R_after,
            scaffolding_before=scaffolding_before,
            scaffolding_after=scaffolding_after,
            prompt=pending.prompt,
            agent_response=pending.llm_response.support_message,
            behavior_t=pending.behavior_t,
            behavior_t_plus_1=behavior_t_plus_1,
            engagement=engagement,
            trace=trace
        )
    
    def step_with_learner_simulator(self, behavior_t: BehaviorTrace,
                                    learner_sim: LearnerSimulator,
                                    context: Dict[str, Any] = None) -> Tuple[StepResult, BehaviorTrace]:
        """
        Full step using learner simulator.
        
        Uses the SAME action_t throughout:
        1. begin_step selects action_t
        2. learner_sim responds to action_t
        3. complete_step uses action_t for Q-learning update
        """
        # Phase 1: begin step - selects action_t ONCE
        pending = self.begin_step(behavior_t, context)
        
        # Learner responds to action_t (no new action selection)
        next_behavior = learner_sim.generate_behavior(
            state=pending.state_t,
            action=pending.action_t,  # SAME action_t
            scaffolding=pending.scaffolding_before
        )
        
        # Phase 2: complete step - uses action_t for Q-learning
        result = self.complete_step(pending, next_behavior)
        
        # Store in learner profile
        learner_sim.profile.states.append(result.state_t_plus_1)
        learner_sim.profile.responsibilities.append(result.R_after)
        learner_sim.profile.actions.append(result.action_t)
        learner_sim.profile.scaffoldings.append(result.scaffolding_after)
        learner_sim.profile.rewards.append(result.reward_t)
        learner_sim.profile.behaviors.append(next_behavior)
        
        return result, next_behavior


# ============================================================================
# UTILITY FUNCTIONS
# ============================================================================

def create_profile(profile_type: str) -> LearnerProfile:
    profiles = {
        'autonomous': {
            'learner_id': 'autonomous_001',
            'initial_autonomy': 0.85,
            'current_autonomy': 0.85,
            'competence': 0.80,
            'help_tendency': 0.70,
            'response_skill': 0.80
        },
        'average': {
            'learner_id': 'average_001',
            'initial_autonomy': 0.50,
            'current_autonomy': 0.50,
            'competence': 0.50,
            'help_tendency': 0.50,
            'response_skill': 0.50
        },
        'dependent': {
            'learner_id': 'dependent_001',
            'initial_autonomy': 0.20,
            'current_autonomy': 0.20,
            'competence': 0.30,
            'help_tendency': 0.30,
            'response_skill': 0.30
        }
    }
    data = profiles.get(profile_type, profiles['average'])
    return LearnerProfile(**data)